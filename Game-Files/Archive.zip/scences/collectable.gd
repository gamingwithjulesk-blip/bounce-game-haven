extends Area2D

@onready var game_maneger = %"game maneger"


func _on_body_entered(body: Node2D) -> void:
	if (body.name == "CharacterBody2D"):
		queue_free()
		game_maneger.add_points()
		
		
